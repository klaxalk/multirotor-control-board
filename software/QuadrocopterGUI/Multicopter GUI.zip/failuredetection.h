#ifndef FAILUREDETECTION_H
#define FAILUREDETECTION_H
#include <QThread>

class failuredetection : public QThread
{
public:
    bool m_abort;
    unsigned char kopter;
    char buffer[80];
    int dataValues[37];
    int samples=0;
    void setKopter(unsigned char kopter);
protected:
    void run();
};

#endif // FAILUREDETECTION_H
