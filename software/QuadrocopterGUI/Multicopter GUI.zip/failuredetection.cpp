#include "failuredetection.h"
#include <iostream>
#include <fstream>
#include <string>
#include "receive.h"
#include "send.h"

using namespace std;
void failuredetection:: run(){
    m_abort=false;
    while(!m_abort)
    {
        dataValues[0] = getTelemetry(kopter,TELEMETRIES.GROUND_DISTANCE_ESTIMATED);
        dataValues[1] = getTelemetry(kopter,TELEMETRIES.GROUND_DISTANCE);
        dataValues[2] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_SPEED);
        dataValues[3] = getTelemetry(kopter,TELEMETRIES.AILERON_SPEED);
        dataValues[4] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_SPEED_ESTIMATED);
        dataValues[5] = getTelemetry(kopter,TELEMETRIES.AILERON_SPEED_ESTIMATED);
        dataValues[6] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_POS_ESTIMATED);
        dataValues[7] = getTelemetry(kopter,TELEMETRIES.AILERON_POS_ESTIMATED);
        dataValues[8] = getTelemetry(kopter,TELEMETRIES.THROTTLE_CONTROLLER_OUTPUT);
        dataValues[9] = getTelemetry(kopter,TELEMETRIES.THROTTLE_SPEED);
        dataValues[10] = getTelemetry(kopter,TELEMETRIES.AILERON_VEL_CONTROLLER_OUTPUT);
        dataValues[11] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_VEL_CONTROLLER_OUTPUT);
        dataValues[12] = getTelemetry(kopter,TELEMETRIES.AILERON_POS_CONTROLLER_OUTPUT);
        dataValues[13] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_POS_CONTROLLER_OUTPUT);
        dataValues[14] = getTelemetry(kopter,TELEMETRIES.THROTTLE_SETPOINT);
        dataValues[15] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_POS_SETPOINT);
        dataValues[16] = getTelemetry(kopter,TELEMETRIES.AILERON_POS_SETPOINT);
        dataValues[17] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_VEL_SETPOINT);
        dataValues[18] = getTelemetry(kopter,TELEMETRIES.AILERON_VEL_SETPOINT);
        dataValues[19] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_SPEED_ESTIMATED2);
        dataValues[20] = getTelemetry(kopter,TELEMETRIES.AILERON_SPEED_ESTIMATED2);
        dataValues[21] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_ACC);
        dataValues[22] = getTelemetry(kopter,TELEMETRIES.AILERON_ACC);
        dataValues[23] = getTelemetry(kopter,TELEMETRIES.VALID_GUMSTIX);
        dataValues[24] = getTelemetry(kopter,TELEMETRIES.ELEVATOR_DESIRED_SPEED_POS_CONT);
        dataValues[25] = getTelemetry(kopter,TELEMETRIES.AILERON_DESIRED_SPEED_POS_CONT);
        dataValues[26] = getTelemetry(kopter,TELEMETRIES.ELE_DES_SPEED_POS_CONT_LEADER);
        dataValues[27] = getTelemetry(kopter,TELEMETRIES.AIL_DES_SPEED_POS_CONT_LEADER);
        dataValues[28] = getTelemetry(kopter,TELEMETRIES.OUTPUT_THROTTLE);
        dataValues[29] = getTelemetry(kopter,TELEMETRIES.OUTPUT_ELEVATOR);
        dataValues[30] = getTelemetry(kopter,TELEMETRIES.OUTPUT_AILERON);
        dataValues[31] = getTelemetry(kopter,TELEMETRIES.OUTPUT_RUDDER);
        dataValues[32] = getTelemetry(kopter,TELEMETRIES.BLOB_DISTANCE);
        dataValues[33] = getTelemetry(kopter,TELEMETRIES.BLOB_HORIZONTAL);
        dataValues[34] = getTelemetry(kopter,TELEMETRIES.BLOB_VERTICAL);
        dataValues[35] = getTelemetry(kopter,TELEMETRIES.PITCH_ANGLE);
        dataValues[36] = getTelemetry(kopter,TELEMETRIES.ROLL_ANGLE);

        sprintf(buffer,"testVlakna_%c",kopter);

        ofstream outputFile(buffer,ios::out | ios::app);
        outputFile << samples;
        outputFile << ",";
        for(int i=0;i<37;i++){
            outputFile << dataValues[i];
            outputFile << ",";
        }
        outputFile << "\n";
        outputFile.close();
        samples++;
    }
}
void failuredetection:: setKopter(unsigned char kpt){
    kopter=kpt;
}

