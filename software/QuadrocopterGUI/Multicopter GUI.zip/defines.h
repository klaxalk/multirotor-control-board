#ifndef defines_H
#define defines_H

typedef char int8_t;

#define LS_STABILIZATION      2
#define LS_LANDING            1
#define LS_ON_GROUND          0
#define LS_TAKEOFF            3
#define LS_FLIGHT             4

#endif // defines_H

#include <stdio.h>
#include <stdlib.h>
