#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QDesktopWidget>
#include <QScreen>
#include <QMessageBox>
#include <QMetaEnum>
#include <QString>
#include <QRunnable>
#include <QThreadPool>
#include <QThread>
#include "serial.h"

int comPort=0;
int i = 0;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->pushButton_2->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    comPort=ui->textEdit->toPlainText().toInt();
    QMessageBox::information(this,"ConnectXbee","Com port sent: " + QString::number(comPort));
     ui->pushButton_2->setEnabled(true);
     startSerial(comPort);  
     thread = new checkThread;
     thread->start();
   //  connect(&mainDataTimer, SIGNAL(timeout()), this, SLOT(realtimeCheck()));
   //  mainDataTimer.start(0);

}

void MainWindow::on_pushButton_2_clicked()
{
    newQuadro = new quadro(this);
    newQuadro->show();
}

void MainWindow::realtimeCheck()
{
checkSerial();
}

void MainWindow::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this,"Multicopter GUI",
                                                                tr("Are you sure?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes) {
        event->ignore();
    } else {
        thread->m_abort=true;
        thread->wait();
        event->accept();
    }
}
